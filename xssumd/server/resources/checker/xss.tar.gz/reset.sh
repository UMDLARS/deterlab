#!/bin/bash

sudo mysql -u root forum < /home/.checker/original.sql
